package Test;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import Main.Factoriel;

public class TestFactoriel {

	Factoriel a;
	@Before
	public void setUp() throws Exception {
		a = new Factoriel();
	}

	@Test
	public void testFacto5() {
		assertEquals(a.factoriel(5),120);
	}
	@Test
	public void testFacto6() {
		assertEquals(a.factoriel(5),700);
	}
	
}
