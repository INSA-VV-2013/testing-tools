package Test;


import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import Main.ObjetA;
import Main.ObjetEau;

public class TestA1 {

	ObjetA a;
	ObjetEau eau;
	@Before
	public void setUp() throws Exception {
		eau = new ObjetEau("Je suis un objet eau.");
		a = new ObjetA(5,10,eau);
	}


	@Test
	public void testEau2(){
		assertEquals(eau.getSeau(),"Je ne suis pas un objet eau.");
	}

}
