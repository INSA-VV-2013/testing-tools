package Main;

public class Factoriel {
	
	public Factoriel(){
		
	}
	public int factoriel(int nb){
		int factoriel = 1;
		for(int i = 1; i<=nb; i++)
			factoriel*=i;
		return factoriel;
	}
}
