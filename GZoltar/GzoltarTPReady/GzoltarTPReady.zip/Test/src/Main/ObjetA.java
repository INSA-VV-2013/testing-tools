package Main;

public class ObjetA {
	private int a;
	private int b;
	private ObjetEau eau;
	public ObjetA(int a, int b,ObjetEau eau){
		this.a = a;
		this.b = b;
		this.eau = eau;
	}
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}
	public int getB() {
		return b;
	}
	public void setB(int b) {
		this.b = b;
	}
	public int aFois2(){
		return a*2;
	}
	public ObjetEau getObjetEau(){
		return eau;
	}
}
