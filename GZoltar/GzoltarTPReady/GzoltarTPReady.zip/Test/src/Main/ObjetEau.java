package Main;

public class ObjetEau {
	
	private String seau;
	
	public ObjetEau(String seau){
		this.seau = seau;
	}
	
	public String getSeau(){
		return seau;
	}
	
}
