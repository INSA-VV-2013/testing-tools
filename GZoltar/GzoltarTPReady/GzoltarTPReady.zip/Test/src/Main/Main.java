package Main;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ObjetEau eau = new ObjetEau("Je suis un objet eau.");
		ObjetA a = new ObjetA(5,100,eau);
		System.out.println("A : "+a.getA());
	}

}
