
public class Personne {
	private Maison maison;
	private Voiture voiture;
	private String nom;
	private String prenom;
	
	public Maison getMaison() {
		return maison;
	}

	public static int oracleTailleDeSaFamille(int n){	
		if (n <= 1) return n;
		else return oracleTailleDeSaFamille(n-1) + oracleTailleDeSaFamille(n-2);
	}
	
	public void setMaison(Maison maison) {
		this.maison = maison;
	}

	public Voiture getVoiture() {
		return voiture;
	}

	public void setVoiture(Voiture voiture) {
		this.voiture = voiture;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public Personne(String nom, String prenom, Maison maison, Voiture voiture){
		this.maison = maison;
		this.voiture = voiture;
		this.nom = nom;
		this.prenom = prenom;
	}
}
