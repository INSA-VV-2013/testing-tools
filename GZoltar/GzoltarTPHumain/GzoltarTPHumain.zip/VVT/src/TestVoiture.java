import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TestVoiture {
	Voiture voiture1;	
	@Before
	public void setUp() throws Exception {
		voiture1 = new Voiture(380,false);
	}

	@Test
	public void testPuissance() {
		assertEquals(voiture1.getPuissance(),380);
	}
}
