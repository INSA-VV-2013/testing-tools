import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;


public class TestPersonne {
	Personne personne1;
	Maison maison1;
	Voiture voiture1;
	@Before
	public void setUp() throws Exception {
		voiture1 = new Voiture(404,false);
		maison1 = new Maison(150, 3);
		personne1 = new Personne("Fran�ois","Hollondo",maison1,voiture1);
	}

	@Test
	public void testPrenom() {
		assertEquals(personne1.getNom(),"Fran�ois");
	}
	
	@Test
	public void testTailleFamille(){
		assertEquals(Personne.oracleTailleDeSaFamille(personne1.getNom().length()),22); //Reponse: 21
	}
}
