
public class Maison {
	private int superficie;
	private int etage;
	
	public Maison(int superficie, int etage){
		this.superficie = superficie;
		this.etage = etage;
	}

	public int getSuperficie() {
		return superficie;
	}

	public void setSuperficie(int superficie) {
		this.superficie = superficie;
	}

	public int getEtage() {
		return etage;
	}

	public void setEtage(int etage) {
		this.etage = etage;
	}
	
}
