
public class Voiture {
	private int puissance;
	private boolean volante;
	
	public Voiture(int puissance, boolean volante){
		this.puissance = puissance;
		this.volante = volante;
	}

	public int getPuissance() {
		return puissance;
	}

	public void setPuissance(int puissance) {
		this.puissance = puissance;
	}

	public boolean isVolante() {
		return volante;
	}

	public void setVolante(boolean volante) {
		this.volante = volante;
	}
}
