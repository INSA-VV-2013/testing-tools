import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;


public class TestMaison {
	Maison maison1;
	@Before
	public void setUp() throws Exception {
		maison1 = new Maison(150, 3);
	}

	@Test
	public void testSuperficie() {
		assertEquals(maison1.getSuperficie(),20);
	}
}
